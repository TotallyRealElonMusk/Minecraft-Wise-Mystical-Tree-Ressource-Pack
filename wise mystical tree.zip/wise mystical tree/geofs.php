<!DOCTYPE html>
<html lang="en"><head><script>window.geofs = window.geofs || {};</script>
<script>geofs.version = '3.35';</script>
<script>geofs.forcePreferenceResetOnVersionChange = '';</script>
<script>geofs.multiplayerHost = 'https://mps.geo-fs.com';</script>
<script>geofs.domain = 'www.geo-fs.com';</script>
<script>geofs.userRoles = {"anonymous":0,"authenticated":1,"student":2,"editor":11,"teacher":40,"subscribed":80,"admin":100};</script>
<script>geofs.masterDomain = 'geo-fs.com';</script>
<script>geofs.scheme = 'https://';</script>
<script>geofs.url = 'https://www.geo-fs.com';</script>
<script>geofs.localUrl = 'https://www.geo-fs.com/';</script>
<script>geofs.googleAppId = '208044912282-4g0gk5oum6gecc2d7ll1ensv921l12us.apps.googleusercontent.com';</script>
<script>geofs.facebookAppId = '404853203195387';</script>
<script>geofs.dataServer = 'https://data2.geo-fs.com/';</script>
<script>geofs.mapXYZ = 'https://data2.geo-fs.com/osm/{z}/{x}/{y}.png';</script>
<script>geofs.blackMarbleServer = '';</script>
<script>geofs.osmTileProvider = 'https://data2.geo-fs.com/osm/{z}/{x}/{y}.png';</script>
<script>geofs.osmServer = 'https://data2.geo-fs.com/osm/';</script>
<script>geofs.landuseServer = 'https://data2.geo-fs.com/landuse/';</script>
<script>geofs.buildingServer = 'https://d1.geo-fs.com/buildings/';</script>
<script>geofs.treeServer = 'https://d1.geo-fs.com/trees/';</script>
<script>geofs.treeServerExtension = '.glbz';</script>
<script>geofs.objectServer = 'https://d1.geo-fs.com/landmarks/';</script>
<script>geofs.ionkey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJiMWQ1NWRlMy1lZmM3LTRlNDYtYWQyOS1hZDlmZmMyZGRiZWUiLCJpZCI6NzYsInNjb3BlcyI6WyJhc3IiXSwiYXNzZXRzIjpbMV0sImlhdCI6MTU1MzUwOTAwMX0.AlJJNDP3yr3dOLmcMnuJdsODGrVoSpm9lvtcXuGM99M';</script>
<title>GeoFS - Fly in Your Web Browser</title><link rel="canonical" href="https://www.geo-fs.com/geofs.php"><meta http-equiv="content-type" content="text/html; charset=utf-8"><meta name="description" content="Fly directly in your web browser without anything to download or to install."><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta property="og:title" content="GeoFS"><meta property="og:type" content="game"><meta property="og:url" content="https://www.geo-fs.com/"><meta property="og:image" content="https://www.geo-fs.com/images/squareposter.jpg"><meta property="og:description" content="Fly directly in your web browser without anything to download or to install."><link rel="shortcut icon" href="favicon.ico"><script src="js/loader.js"></script><!-- Common CSS --><link rel="stylesheet" type="text/css" href="/css/commonCSS.css?kc=1652449784-4" media="screen"/><!-- Common JS --><script data-deferredsrc="/js/commonJS.js?kc=1652449784"></script><!-- 3rd parties --><!-- CESIUM --><!--
    <link rel="stylesheet" type="text/css" href="/projects/GeoFS/libs/3rdp/Cesium/1-96/Widgets/widgets.css" media="screen"/>
    <script defer src="/projects/GeoFS/libs/3rdp/Cesium/1-96/Cesium.js" obfuscation="update" dest="js/Cesium/build/Cesium.js"></script>
    --><!--
    <link rel="stylesheet" type="text/css" href="/projects/CESIUM/Build/Cesium/Widgets/widgets.css" media="screen"/>
    <script defer src="/projects/CESIUM/Build/Cesium/Cesium.js" obfuscation="update" dest="js/Cesium/build/Cesium.js"></script>
    --><script defer data-deferredsrc="js/Cesium/build/Cesium.js"></script><!-- Common libs --><!-- Custom shaders --><!-- Sim --><!-- Data --><script defer data-deferredsrc="data/runwaygrid.js"></script><script defer data-deferredsrc="data/airports.js"></script><script data-deferredsrc="https://www.googletagmanager.com/gtag/js?id=UA-2996341-8"></script><script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-2996341-8');
    </script><script>geofs.PRODUCTION = true;geofs.killCache = '?kc=1669908241';</script><script data-deferredsrc="/js/geofs.js?kc=1669908241-2"></script><link rel="stylesheet" type="text/css" href="css/geofs.css?kc=1669908241" media="screen"/></head><body class="geofs geofs-ingame " style="overflow: hidden;">

    <div class="geofs-ui-left">

        <div class="geofs-apiResponse"></div>

        <ul class="geofs-list geofs-toggle-panel geofs-preference-list geofs-preferences"
    data-noblur="true"
    data-onshow="{geofs.initializePreferencesPanel()}"
    data-onhide="{geofs.savePreferencesPanel()}">

    <li class="geofs-list-collapsible-item geofs-preference-controls">Controls

        <ul class="geofs-list geofs-collapsible">
            <!-- Controls -->
            <li>Select a control device and configure it.</li>

            <li class="no-hover geofs-list-collapsible-item geofs-hideForApp">
                <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect geofs-stopMousePropagation geofs-expendable-radio" for="control-keyboard">

                    <input type="radio" id="control-keyboard" class="mdl-radio__button" name="control"
                           data-update="{controls.setMode(value)}"
                           data-gespref="geofs.preferences.controlMode"
                           data-matchvalue="keyboard"/>
                    <span class="mdl-radio__label">Keyboard [K]
                    </span>
                </label>
                configure
                <div class="geofs-collapsible">

                    <fieldset>
                        <legend>
                            Settings
                        </legend>

                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="keyboardMixYawRoll" title="Mixes the rudder with the ailerons input">
                            <input type="checkbox" id="keyboardMixYawRoll" class="mdl-switch__input" data-gespref="geofs.preferences.keyboard.mixYawRoll" data-update="{controls.setMode()}">
                            <span class="mdl-switch__label">Mix Roll/Yaw</span>
                        </label>

                        <div title="Sets how much rudder is mixed from the ailerons input" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.keyboard.mixYawRollQuantity"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="4" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Roll/Yaw Mix Ratio</label>
                        </div>

                        <div title="Sets how quickly the input responds" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.keyboard.sensitivity" data-update="{controls.setMode()}" value="0"
                             data-min="0.1" data-max="4" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Sensitivity</label>
                        </div>

                        <!--
                        <br/>Exponential: <div data-max="2" step="0.1" class="geofs-ui-slider" data-gespref="geofs.preferences.keyboard.exponential" ></div>
                        -->
                    </fieldset>
                    <fieldset>
                        <legend>
                            Keys
                        </legend>
                        <div class="geofs-keyboard-keys-container">
                            <!-- pouplated by javascript - preferences.js-->
                        </div>
                    </fieldset>
                </div>
            </li>
            <li class="no-hover geofs-list-collapsible-item geofs-hideForApp">
                <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect geofs-stopMousePropagation geofs-expendable-radio" for="control-mouse">

                    <input type="radio" id="control-mouse" class="mdl-radio__button" name="control"
                           data-update="{controls.setMode(value)}"
                           data-gespref="geofs.preferences.controlMode"
                           data-matchvalue="mouse"/>

                    <span class="mdl-radio__label">Mouse [M]</span>
                </label>
                configure
                <div class="geofs-collapsible">
                    <fieldset>
                        <legend>
                            Settings
                        </legend>

                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="mouseMixYawRoll" title="Mixes the rudder with the ailerons input">
                            <input type="checkbox" id="mouseMixYawRoll" class="mdl-switch__input" data-gespref="geofs.preferences.mouse.mixYawRoll" data-update="{controls.setMode()}">
                            <span class="mdl-switch__label">Mix Roll/Yaw</span>
                        </label>

                        <div title="Sets how much rudder is mixed from the ailerons input" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.mouse.mixYawRollQuantity"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="4" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Roll/Yaw Mix Ratio</label>
                        </div>

                        <div title="Sets how quickly the input responds" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.mouse.sensitivity" data-update="{controls.setMode()}" value="0"
                             data-min="0.1" data-max="2" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Sensitivity</label>
                        </div>

                        <div title="For hight value, input will be gentle near the center and fast at the extremes"
                             class="slider" data-type="slider" data-gespref="geofs.preferences.mouse.exponential"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="2" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Exponential</label>
                        </div>

                    </fieldset>
                </div>
            </li>
            <li class="no-hover geofs-list-collapsible-item">
                <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect geofs-stopMousePropagation geofs-expendable-radio" for="control-joystick">
                    <input type="radio" id="control-joystick" class="mdl-radio__button" name="control"
                           data-update="{controls.setMode(value)}"
                           data-gespref="geofs.preferences.controlMode"
                           data-matchvalue="joystick"/>
                    <span class="mdl-radio__label geofs-hideForMobile">Joystick [J]</span>
                    <span class="mdl-radio__label geofs-onlyForMobile">Gamepad</span>
                </label>
                configure
                <div class="geofs-collapsible geofs-preferences-joystick">

                    <fieldset class="geofs-preferences-joystick-status">
                        <legend>
                            Device Status
                        </legend>
                        <div class="alert alert-error">
                            <b style="color: red;">Your browser does not appear to support the native GamePad API</b>
                        </div>
                        <div class="alert alert-warning">
                            <b>Joystick not detected:</b> press a button on the Joystick to enable it.
                        </div>
                        <div class="alert alert-success"></div>
                    </fieldset>

                    <fieldset>
                        <legend>
                            Settings
                        </legend>

                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="joystickMixYawRoll" title="Mixes the rudder with the ailerons input">
                            <input type="checkbox" id="joystickMixYawRoll" class="mdl-switch__input" data-gespref="geofs.preferences.joystick.mixYawRoll" data-update="{controls.setMode()}">
                            <span class="mdl-switch__label">Mix Roll/Yaw</span>
                        </label>

                        <div title="Sets how much rudder is mixed from the ailerons input" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.joystick.mixYawRollQuantity"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="4" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Roll/Yaw Mix Ratio</label>
                        </div>

                        <div title="Sets how quickly the input responds" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.joystick.sensitivity" data-update="{controls.setMode()}" value="0"
                             data-min="0.1" data-max="2" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Sensitivity</label>
                        </div>

                        <div title="For hight value, input will be gentle near the center and fast at the extremes"
                             class="slider" data-type="slider" data-gespref="geofs.preferences.joystick.exponential"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="2" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Exponential</label>
                        </div>

                    </fieldset>
                    <fieldset>
                        <legend>
                            Axes
                        </legend>
                        <div class="geofs-joystick-calibration" style="position: relative;">
                            <button class="mdl-button mdl-js-button mdl-button--raised geofs-joystick-startCalibration" style="position: absolute; right: 10px; top: -15px;" onclick="controls.joystick.startCalibration();" title="Joystick calibration">Calibrate</button>
                            <div class="geofs-preferences-comment geofs-calibrating" style="display: none; color: #ab8000;">Calibrating: move all axes to full range of motion (<span class="geofs-joystick-calibrationProgress" style="font-weight: bold;"></span>)</div>
                            <div class="geofs-preferences-comment geofs-calibrated">Move the joystick to check activity</div>
                        </div>
                        <div class="geofs-joystick-axes-container">
                            <!-- Populated by javascript - preferences.js -->
                        </div>
                    </fieldset>
                    <fieldset>
                        <legend>
                            Buttons
                        </legend>
                        <div class="geofs-preferences-comment">
                            Press joystick buttons to check activity
                        </div>
                        <div class="geofs-joystick-button-container">
                            <!-- Populated by javascript - preferences.js -->
                        </div>
                    </fieldset>
                </div>
            </li>
            <li class="no-hover geofs-list-collapsible-item geofs-preferences-orientation geofs-onlyForMobile">
                <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect geofs-stopMousePropagation geofs-expendable-radio" for="control-orientation">
                    <input type="radio" id="control-orientation" class="mdl-radio__button" name="control"
                           data-update="{controls.setMode(value)}"
                           data-gespref="geofs.preferences.controlMode"
                           data-matchvalue="orientation"/>
                    <span class="mdl-radio__label">Orientation
                    </span>
                </label>
                configure
                <div class="geofs-collapsible">

                    <fieldset>
                        <legend>
                            Settings
                        </legend>

                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="orientationMixYawRoll" title="Mixes the rudder with the ailerons input">
                            <input type="checkbox" id="orientationMixYawRoll" class="mdl-switch__input" data-gespref="geofs.preferences.orientation.mixYawRoll" data-update="{controls.setMode()}"/>
                            <span class="mdl-switch__label">Mix Roll/Yaw</span>
                        </label>

                        <div title="Sets how much rudder is mixed from the ailerons input" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.orientation.mixYawRollQuantity"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="4" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Roll/Yaw Mix Ratio</label>
                        </div>

                        <div title="Sets how quickly the input responds" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.orientation.sensitivity" data-update="{controls.setMode()}" value="0"
                             data-min="0.1" data-max="2" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Sensitivity</label>
                        </div>

                        <div title="For hight value, input will be gentle near the center and fast at the extremes"
                             class="slider" data-type="slider" data-gespref="geofs.preferences.orientation.exponential"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="2" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Exponential</label>
                        </div>

                    </fieldset>
                    <fieldset style="float: left;">
                        <legend>
                            Axis
                        </legend>
                        <div class="geofs-preferences-comment">
                            Move the device to check activity.
                        </div>
                        <div class="geofs-feedback-wrapper">
                            <label>Pitch</label>
                            <select data-gespref="geofs.preferences.orientation.axis.pitch">
                                <option value="none">None</option>
                                <option value="0">Axis 0</option>
                                <option value="1">Axis 1</option>
                            </select>
                            <div class="progress" axis="pitch" centered="true">
                                <div class="bar"></div>
                            </div>

                            <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="reverseOrientationPitch" title="Inverse axis">
                                <input type="checkbox" id="reverseOrientationPitch" class="mdl-switch__input" data-gespref="geofs.preferences.orientation.multiplier.pitch" data-update="{controls.setMode()}">
                                <span class="mdl-switch__label">Inverse</span>
                            </label>

                        </div>
                        <div class="geofs-feedback-wrapper">
                            <label>Roll</label>
                            <select data-gespref="geofs.preferences.orientation.axis.roll">
                                <option value="none">None</option>
                                <option value="0">Axis 0</option>
                                <option value="1">Axis 1</option>
                            </select>
                            <div class="progress" axis="roll" centered="true">
                                <div class="bar"></div>
                            </div>

                            <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="reverseOrientationRoll" title="Inverse axis">
                                <input type="checkbox" id="reverseOrientationRoll" class="mdl-switch__input" data-gespref="geofs.preferences.orientation.multiplier.roll" data-update="{controls.setMode()}">
                                <span class="mdl-switch__label">Inverse</span>
                            </label>

                        </div>

                    </fieldset>

                    <div class="geofs-orientationReset geofs-orientationCalibratePerm" style="float: left; margin-top: 0px; display: inline-block; position: relative;">
                        <i class="material-icons md-48">
                            adjust
                        </i>
                        <br/>
                        Tap to center controls
                    </div>
                </div>
            </li>
            <li class="no-hover geofs-list-collapsible-item geofs-preferences-touch geofs-onlyForMobile">
                <label class="mdl-radio mdl-js-radio mdl-js-ripple-effect geofs-stopMousePropagation geofs-expendable-radio" for="control-touch">
                    <input type="radio" id="control-touch" class="mdl-radio__button" name="control"
                           data-update="{controls.setMode(value)}"
                           data-gespref="geofs.preferences.controlMode"
                           data-matchvalue="touch"/>
                    <span class="mdl-radio__label">Touch Stick
                    </span>
                </label>
                configure
                <div class="geofs-collapsible">

                    <fieldset>
                        <legend>
                            Settings
                        </legend>

                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="touchMixYawRoll" title="Mixes the rudder with the ailerons input">
                            <input type="checkbox" id="touchMixYawRoll" class="mdl-switch__input" data-gespref="geofs.preferences.touch.mixYawRoll" data-update="{controls.setMode()}"/>
                            <span class="mdl-switch__label">Mix Roll/Yaw</span>
                        </label>

                        <div title="Sets how much rudder is mixed from the ailerons input" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.touch.mixYawRollQuantity"
                             data-update="{controls.setMode()}" value="0" data-min="0.1" data-max="4" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Roll/Yaw Mix Ratio</label>
                        </div>

                        <div title="Sets how quickly the input responds" class="slider" data-type="slider"
                             data-gespref="geofs.preferences.touch.sensitivity" data-update="{controls.setMode()}" value="0"
                             data-min="0.01" data-max="1" data-precision="2">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Sensitivity</label>
                        </div>

                        <div title="For hight value, input will be gentle near the center and fast at the extremes"
                             class="slider" data-type="slider" data-gespref="geofs.preferences.touch.exponential"
                             data-update="{controls.setMode()}" value="0" data-min="1" data-max="3" data-precision="1">
                            <div class="slider-rail">
                                <div class="slider-selection">
                                    <div class="slider-grippy">
                                        <input class="slider-input"/>
                                    </div>
                                </div>
                            </div>
                            <label>Exponential</label>
                        </div>

                    </fieldset>
                </div>
            </li>
        </ul>
    </li>
    <li class="geofs-list-collapsible-item geofs-hideForApp">General

        <div class="geofs-collapsible">
            <fieldset>
                <legend>
                    Sound Volume
                </legend>
                <div title="Sound Volume"
                     class="slider" data-type="slider" data-gespref="geofs.preferences.volume"
                     data-update="{audio.soundplayer.setMasterVolume()}" value="1" data-min="0" data-max="1" data-precision="1">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Volume</label>
                </div>
            </fieldset>
            <fieldset>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="crashDetection" title="Enable crash detection">
                    <input type="checkbox" id="crashDetection" class="mdl-switch__input" data-gespref="geofs.preferences.crashDetection">
                    <span class="mdl-switch__label">Detect crashes</span>
                </label>
            </fieldset>
            <fieldset class="geofs-hideForApp">
                <!-- Colored mini FAB button -->
                <button class="mdl-button mdl-js-button mdl-button--raised " onclick="geofs.getLink();" title="Get a URL to the current flight and location">
                    Generate a link to the current location
                </button>
                <div class="geofs-linkOutput"></div>
            </fieldset>
            <fieldset class="geofs-hideForApp">
                <legend>
                    Multi-monitor
                </legend>
                <button class="mdl-button mdl-js-button mdl-button--raised" onclick="geofs.camera.openSlaveWindow(-1);" title="Extend screen to the left">
                    Open left screen
                </button>
                <button class="mdl-button mdl-js-button mdl-button--raised" onclick="geofs.camera.openSlaveWindow(1);" title="Extend screen to the right">
                    Open right screen
                </button>
            </fieldset>
            <fieldset class="geofs-hideForApp">
                <legend>
                    Slave screens graphics quality
                </legend>
                <div title="Quality Level"
                     class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.slaveQuality"
                     value="3" data-min="1" data-max="6" data-precision="0">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Slave window quality</label>
                </div>
            </fieldset>
        </div>
    </li>

    <li class="geofs-list-collapsible-item geofs-multiplayer-preferences">Multiplayer

        <div class="geofs-collapsible">
            <!-- Multiplayer -->
            <fieldset>

                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="enableMultiplayer" title="Enable multiplayer">
                    <input type="checkbox" id="enableMultiplayer" class="mdl-switch__input" data-gespref="geofs.preferences.multiplayer"
                           data-update="{if (this.checked) {multiplayer.start();} else {multiplayer.stop();}}" />
                    <span class="mdl-switch__label">Enable multiplayer</span>
                </label>

                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-notstudent-role" for="showCommunityMultiplayer" title="Show Community Contributed Aircraft">
                    <input type="checkbox" id="showCommunityMultiplayer" class="mdl-switch__input" data-gespref="geofs.preferences.showCommunityMultiplayer" />
                    <span class="mdl-switch__label">Show Community Contributed 3D Models </span>
                    <i style="margin-top: -9px;position: absolute;margin-left: 23px;display: block;font-size: 12px;">Performance is not guarantied</i>
                </label>

                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="enableADSB" title="Enable ADS-B Traffic">
                    <input type="checkbox" id="enableADSB" class="mdl-switch__input" data-gespref="geofs.preferences.adsb" />
                    <span class="mdl-switch__label">Show ADS-B commercial traffic</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="enableChat" title="Enable text chat">
                    <input type="checkbox" id="enableChat" class="mdl-switch__input geofs-enabledWhenAuthenticated" data-gespref="geofs.preferences.chat" data-update="{if (!this.checked) {ui.chat.hide();}}" />
                    <span class="mdl-switch__label geofs-notstudent-role">Enable text chat (I am over 13)</span>
                    <span class="mdl-switch__label geofs-student-role">Enable text chat</span>
                </label>
                <i class="geofs-hideForApp geofs-notstudent-role">By enabling GeoFS chat, you confirm<br/>that you are over 13 years of age.<br/></i>
                <i class="geofs-loggedout geofs-hideForApp geofs-notstudent-role">You must be logged in to use the chat<br/></i>
                <i class="geofs-hideForApp geofs-notstudent-role">The chat is self moderated: please stay courteous.</i>
            </fieldset>
<!--
            <fieldset>
                <legend>
                    Discord audio chat
                </legend>
                A Discord server is available for audio chat in GeoFS.
                <a href="https://discordapp.com/invite/dGpuATu" target="_blank" rel="nofollow"><img src="images/discord.png"/></a>
            </fieldset>
-->
        </div>
    </li>

    <li class="geofs-list-collapsible-item">Graphics

        <div class="geofs-collapsible">
            <!-- Graphics -->
            <fieldset>
                <legend class="geofs-hideForApp">
                    Performance vs. Quality - Anything above 3 requires a fast computer
                </legend>
                <legend class="geofs-onlyForApp">
                    Performance vs. Quality - (resolution, viewing distance, amount of clouds, ...)
                </legend>
                <div title="Quality Level"
                     class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.quality"
                     data-update="{geofs.api.renderingQuality()}" value="3" data-min="1" data-max="6" data-precision="0">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Quality Level</label>
                </div>
            </fieldset>
            <fieldset class="geofs-advancedGraphics geofs-advanced">
                <legend>
                    Advanced
                </legend>
                <div class="geofs-stopMousePropagation">
                    <div title="Resolution" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.resolutionScale" data-update="{geofs.api.advancedRenderingQuality()}" value="0" data-min="0.3" data-max="1.0" data-precision="1">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Resolution</label>
                    </div>
                    <div title="Viewing Distance" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.viewingDistance" data-update="{geofs.api.advancedRenderingQuality()}" value="0" data-min="1" data-max="7" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Viewing Distance</label>
                    </div>
                    <div title="Tiles Cache Size" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.tileCacheSize" data-update="{geofs.api.advancedRenderingQuality()}" value="0" data-min="0" data-max="5000" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Tiles Cache Size</label>
                    </div>
                    <div title="Shadow Quality" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.shadowQuality" data-update="{geofs.api.advancedRenderingQuality()}" value="0" data-min="1" data-max="4" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Shadow Quality</label>
                    </div>
                    <div title="Clouds Density" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.cloudDensity" data-update="{geofs.api.advancedRenderingQuality()}" value="0" data-min="0" data-max="1" data-precision="1">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Billboard Clouds Density</label>
                    </div>
                    <div title="Atmosphere Scattering and Volumetric Clouds Quality" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.scatteringQuality" data-update="{geofs.api.advancedRenderingQuality()}" value="1" data-min="1" data-max="7" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Atmo. & Vol. Clouds Quality</label>
                    </div>
                    <div title="Vegetation Quality" class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.advanced.vegetationQuality" data-update="{geofs.api.advancedRenderingQuality()}" value="2" data-min="1" data-max="3" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Vegetation Quality</label>
                    </div>
                    <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="fxaa" title="Anti Aliasing">
                        <input type="checkbox" id="fxaa" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.advanced.fxaa"
                               data-update="{geofs.api.advancedRenderingQuality()}" />
                        <span class="mdl-switch__label">Anti Aliasing</span>
                    </label>
                    <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="dropShadow" title="Drop Shadows">
                        <input type="checkbox" id="dropShadow" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.advanced.dropShadow"
                               data-update="{geofs.api.advancedRenderingQuality()}" />
                        <span class="mdl-switch__label">Drop shadows</span>
                    </label>
                    <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="globeLighting" title="Globle Lighting">
                        <input type="checkbox" id="globeLighting" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.advanced.globeLighting"
                               data-update="{geofs.api.advancedRenderingQuality()}" />
                        <span class="mdl-switch__label">Globe Lighting</span>
                    </label>
                </div>
            </fieldset>
            <fieldset>
                <legend>
                    Color enhancement
                </legend>
                <div title="Imagery Color Enhancement"
                     class="slider" data-type="slider" data-gespref="geofs.preferences.graphics.enhanceColors"
                     data-update="{geofs.api.enhanceColors(value)}" value="0" data-min="0" data-max="1.4" data-precision="1">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Enhancement Level</label>

                </div>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="advancedAtmosphere" title="Advanced Atmosphere">
                    <input type="checkbox" id="advancedAtmosphere" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.advancedAtmosphere"
                           data-update="{geofs.api.renderingQuality()}">
                    <span class="mdl-switch__label">Advanced Atmosphere</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="volumetricClouds" title="Volumetric clouds">
                    <input type="checkbox" id="volumetricClouds" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.volumetricClouds"
                           data-update="{geofs.api.renderingQuality()}">
                    <span class="mdl-switch__label">Volumetric clouds</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="buildings" title="Enable Buildings">
                    <input type="checkbox" id="buildings" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.buildings"
                           data-update="{geofs.api.setBuildings(this.checked)}">
                    <span class="mdl-switch__label">Buildings (experimental)</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="vegetation" title="Enable Vegetation">
                    <input type="checkbox" id="vegetation" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.vegetation"
                           data-update="{geofs.api.setVegetation(this.checked)}">
                    <span class="mdl-switch__label">Vegetation (experimental)</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="waterEffect" title="Enable water effect">
                    <input type="checkbox" id="waterEffect" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.waterEffect"
                           data-update="{geofs.api.setWaterEffect(this.checked)}">
                    <span class="mdl-switch__label">Water effect</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="contrails" title="Enable contrails">
                    <input type="checkbox" id="contrails" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.contrails" />
                    <span class="mdl-switch__label">Contrails</span>
                </label>
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-onlyForSubscribers" for="hdonoff" title="Enable HD images">
                    <input type="checkbox" id="hdonoff" class="mdl-switch__input" data-gespref="geofs.preferences.graphics.HD"
                           data-update="{if (geofs.preferences.graphics.HD==this.checked) geofs.api.setHD(this.checked)}">
                    <span class="mdl-switch__label">Enable HD</span>
                </label>

                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="headMotion" title="Enable head acceleration motion">
                    <input type="checkbox" id="headMotion" class="mdl-switch__input" data-gespref="geofs.preferences.camera.headMotion">
                    <span class="mdl-switch__label">Cockpit view head motion</span>
                </label>

                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect geofs-hideForApp" for="transparentUi" title="Toggle transparent User Interface">
                    <input type="checkbox" id="transparentUi" class="mdl-switch__input" data-gespref="geofs.preferences.interface.transparent"
                           data-update="{ui.applyPreferences()}">
                    <span class="mdl-switch__label">Transparent User Interface</span>
                </label>

                <div class="geofs-HDPurchase-view geofs-hideForApp"></div>
                <div class="geofs-hdTrial-view geofs-hideForApp" style="position: relative;">
                    <script>geofs.userRecord={"id":"602445","email":"nvzurzolo@gmail.com","googleid":"111310387754326896562","facebookid":null,"deviceid":null,"schoolid":null,"externalid":null,"firstname":"TotallyRealElonMusk","lastname":"","callsign":"ElonMusk[Alt]","sessionId":"rg15tqeea0nccuaunqvvdghm9r","created":"2022-06-12 16:44:19","active":"1","ip":"91.170.6.146","role":"1","muted":"4","banned":"0","lastlogin":"2022-12-03 19:26:22","mailing":"0","password":"***","flighttime":"1380","preferences":null,"mutelist":null,"premium":null,"transactionDate":null,"transactionReference":null,"transactionStatus":null,"transactionMessage":null,"subscribed":false,"subscriptionStart":null,"subscriptionEnd":null,"trial":"0","subscriptionDaysLeft":0};</script>
<script>geofs.userRecord.muteList=[];</script>
<script>document.body.classList.remove('geofs-subscribed')</script>

<script>


    function initTrial() {

        if (window.trialInitialized) return;

        $(document).one('loginchange', function() {
            $('.geofs-hdTrial-view').htmlView('load', geofs.url + '/html/hd/trial.php');
        });

        $(window).one('subscriptionchange', function() {
            $('.geofs-hdTrial-view').htmlView('load', geofs.url + '/html/hd/trial.php');
        });

        startHDTrial = function(node, paymentData) {
            // 'node' is a reference to the Checkout container HTML node.
            // 'paymentData' is the result of the payment. Includes 'payload' variable,
            // which you should submit to the server for the Checkout API /verify call.

            $.ajax('/backend/accounts/hd.php?method=startHDTrial').done(function() {
                $('.geofs-hdTrial-view').htmlView('load', geofs.url + '/html/hd/trial.php?d=true');
                $('.geofs-HDPurchase-view').htmlView('load', geofs.url + '/html/hd/subscription.php');
            });

            return false;
        };

        window.trialInitialized = true;
    };

    window.executeOnEventDone('afterDeferredload', initTrial);

</script>


<div class="geofs-trial-frame"><h5>Try HD, free, for a day!</h5><p>Before purchasing a subscription, try HD satellite images <b>free</b> for one-day.</p><div style="text-align: center;"><a class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent mdl-js-ripple-effect" href="#" onclick="startHDTrial();">Start free one-day HD trial</a></div></div>                </div>
            </fieldset>
        </div>
    </li>

    <li class="geofs-list-collapsible-item">Environment

        <div class="geofs-collapsible">
            <!-- Weather -->
            <fieldset class="geofs-hideForLight">
                <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect" for="weatherManual" title="Set environment manually">
                    <input type="checkbox" id="weatherManual" class="mdl-switch__input" data-gespref="geofs.preferences.weather.manual"
                           data-update="{weather.refresh();geofs.api.renderingQuality()}">
                    <span class="mdl-switch__label">Set environment manually</span>
                </label>
            </fieldset>

            <fieldset>
                <legend>METAR</legend>
                <div class="geofs-metarDisplay"></div>
            </fieldset>

            <fieldset class="geofs-manualWeather">
                <legend>
                    Time of the day
                </legend>

                <div title="Set time of day" class="slider geofs-timeSlider" data-type="slider"
                     data-gespref="geofs.preferences.weather.localTime" data-update="{weather.setDateAndTime()}" value="" data-min="0"
                     data-max="24" data-precision="2">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <span class="slider-input-overlay"></span>
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Time of the day in hours</label>
                </div>
            </fieldset>

            <fieldset class="geofs-manualWeather">
                <legend>
                    Weather
                </legend>
                <div title="Weather quality"
                     class="slider" data-type="slider" data-gespref="geofs.preferences.weather.quality"
                     data-update="{weather.setManual()}" value="0" data-min="0" data-max="100" data-precision="0">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Weather quality</label>
                </div>

                <div title="Season"
                     class="slider geofs-seasonSlider" data-type="slider" data-gespref="geofs.preferences.weather.season"
                     data-update="{weather.setManual()}" value="" data-min="0" data-max="100" data-precision="0">
                    <div class="slider-rail">
                        <div class="slider-selection">
                            <div class="slider-grippy">
                                <span class="slider-input-overlay"></span>
                                <input class="slider-input"/>
                            </div>
                        </div>
                    </div>
                    <label>Season</label>
                </div>

            </fieldset>

            <fieldset class="geofs-manualWeather geofs-advancedWeather geofs-advanced">
                <legend>
                    Advanced
                </legend>
                <div class="geofs-stopMousePropagation">
                    <div title="Clouds" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.clouds" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="100" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Clouds</label>
                    </div>
                    <div title="CloudsCeiling" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.ceiling" data-update="{weather.setAdvanced()}" value="1500" data-min="1" data-max="5000" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Clouds Ceiling m.</label>
                    </div>
                    <div title="Precipitations" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.precipitationAmount" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="100" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Precipitations</label>
                    </div>
                    <div title="Fog" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.fog" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="100" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Fog</label>
                    </div>
                    <div title="FogCeiling" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.fogCeiling" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="3000" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Fog Ceiling m.</label>
                    </div>
                    <div title="windSpeed" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.windSpeedMS" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="20" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Wind Speed m/s.</label>
                    </div>
                    <div title="windDirection" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.windDirection" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="360" data-precision="0">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Wind Direction Deg.</label>
                    </div>
                    <div title="turbulences" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.turbulences" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="1" data-precision="1">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Turbulences.</label>
                    </div>
                    <div title="thermals" class="slider" data-type="slider" data-gespref="geofs.preferences.weather.advanced.thermals" data-update="{weather.setAdvanced()}" value="0" data-min="0" data-max="1" data-precision="1">
                        <div class="slider-rail"><div class="slider-selection"><div class="slider-grippy"><input class="slider-input"/></div></div></div><label>Thermals.</label>
                    </div>
                </div>
            </fieldset>
        </div>
    </li>

    
        <li class="geofs-list-collapsible-item">Debug info
        <div class="geofs-collapsible geofs-tab-debug">
            <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" onclick="window.location.reload(true);">Reload GeoFS with clean cache</button>
            <div class="geofs-debug-info"></div>
        </div>
    </li>
    <!-- Bottom buttons -->
    <div class="geofs-preferenceForm">
        <div style="float: left;">
            <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" onclick="geofs.resetPreferences(/*refreshPanel*/ true);">Reset Settings</button>
        </div>
        <div style="float: right;">
            <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--accent geofs-hideForApp" onclick="geofs.savePreferencesPanel(); ui.closePreferencePanel();">Save & Close</button>
        </div>
    </div>
    </ul><ul class="geofs-list geofs-toggle-panel geofs-location-list">

    <li class="geofs-list-collapsible-item">Approaches
        <ul class="geofs-collapsible">
            <li data-location="geofs.flyTo([36.145,-5.551,800,90, true]);">Gibraltar Int'l</li>
            <li data-location="geofs.flyTo([37.807416414832694,-122.6137032378986,309,173.32, true]);">USS John C. Stennis (Carrier)</li>
            <li data-location="geofs.flyTo([24.55734481134812,-81.71068081353695,500,-91.41, true]);">Key West Int'l.</li>
            <li data-location="geofs.flyTo([45.43225365746484,6.683131212012103,2500,-134, true]);">Courchevel Altiport</li>
            <li data-location="geofs.flyTo([18.034682701324222,-63.15433542979288,350,82, true]);">Princess Juliana Airport, Saint Maarten</li>
            <li data-location="geofs.flyTo([32.73121515773958,-16.735523534674982,317,-134, true]);">Santa Catarina Airport (Funchal), Madeira</li>
            <li data-location="geofs.flyTo([43.71957166711304,7.303216893528995,450,-135.72, true]);">Aéroport Nice Côte d'Azur</li>
            <li data-location="geofs.flyTo([27.660295165543864,86.7058402035465,3255,31, true]);">Lukla - Nepal (approach)</li>
            <li data-location="geofs.flyTo([17.6543948750155,-63.24368391186655,154,115, true]);">Juancho E. Yrausquin - Saba (approach)</li>
            <li data-location="geofs.flyTo([43.578924,-6.09867,550,104, true]);">Asturias - Spain (approach)</li>
            <li data-location="geofs.flyTo([30.578892650446615,2.814844431592091,800,102.44, true]);">El Golea, Algeria (approach)</li>
            <li data-location="geofs.flyTo([17.9039979948387,-62.85894189052203,162,87, true]);">Saint Barthélemy (approach)</li>
            <li data-location="geofs.flyTo([56.998322183007005,-7.410804568469447,376,-47, true]);">Barra Airport - Scotland (beach landing)</li>
        </ul>
    </li>

    <li class="geofs-list-collapsible-item">On Runway
        <ul class="geofs-collapsible">
            <li data-location="geofs.flyTo([42.36021520436057,-70.98767662157663,0,-103.54]);">Logan Int'l (Boston) - 27</li>
            <li data-location="geofs.flyTo([25.800717256450998,-80.30116643603567,0,87.65]);">Miami Int'l - 8R</li>
            <li data-location="geofs.flyTo([43.66555302435758,7.228367855065596,0,-135]);">Aéroport Nice Côte d'Azur - 22L</li>
    <!-- <li data-location="geofs.flyTo([37.78009384234325,-122.60911495155936,0,172]);">USS John C. Stennis (Carrier)</li> -->
            <li data-location="geofs.flyTo([37.7793,-122.60887,0,175]);">USS John C. Stennis (Carrier)</li>
            <li data-location="geofs.flyTo([33.93726741762918,-118.38364975124578,0,-96.50347129433592]);">Los Angeles Int'l, USA - 25L</li>
            <li data-location="geofs.flyTo([43.67416610318312,10.384369181910223,0,36.54]);">Pisa - Italy - 04R</li>
            <li data-location="geofs.flyTo([46.970496925890174,8.385052215851225,0,64]);">Buochs - Switzerland -  07L</li>
            <li data-location="geofs.flyTo([53.33191343454627,-2.3107668633750715,0,51.43]);">Manchester Int'l - UK - 05</li>
            <li data-location="geofs.flyTo([25.247580920322463,55.381149447648966,0,-58.28]);">Dubai Int'l - UAE - 30L</li>
            <li data-location="geofs.flyTo([44.838118548285536,-0.7018235748525906,0,226]);">Bordeaux - France</li>
            <li data-location="geofs.flyTo([-29.930402181454788,27.84595492343562,0,56]);">Matekane Air Strip – Lesotho</li>
        </ul>
    </li>

    <li data-location="geofs.flyTo([45.938149486108856,6.892803255304612,1500,37.89311560373897]);">Chamonix - Alps - France</li>
    <li data-location="geofs.flyTo([37.76577100453262,-122.36941785026704,455,-51.942644559501176]);">San Francisco - USA</li>
    <li data-location="geofs.flyTo([36.110353463200575,-113.24040648366983,1288,-140.62100383790101]);">Grand Canyon - USA</li>
    <li data-location="geofs.flyTo([55.93793884878086,-4.9214302700610455,302,350,0]);">West Coast of Scotland</li>
    <li data-location="geofs.flyTo([37.969320063220124,23.706062632829592,290,95.18337970067272]);">Acropolis - Athens - Greece</li>
    <li data-location="geofs.flyTo([28.061109245551233,86.97510753197244,2500,-151]);">Mount Everest - Nepal</li>
    <li data-location="geofs.flyTo([47.605820095333414,10.716154924389544,1077,153.4510132877216]);">Neuschwanstein Castle - Germany</li>
    <li data-location="geofs.flyTo([43.76783434260276,11.37363711588644,863,-95.0858221868535]);">Florence - Tuscany - Italy</li>
    <li data-location="geofs.flyTo([31.82873125749288,-0.6928899020410576,940,55]);">Sahara - Algeria</li>
    <li data-location="geofs.flyTo([-14.81065560936189,-74.97137062648335,1179,-56.668584418305656]);">Nazca - Peru</li>
    <li data-location="geofs.flyTo([52.34043382703594,4.900905358384406,325,4.323532809932645]);">Amsterdam - Netherlands</li>
    <li data-location="geofs.flyTo([-25.365600382613092,131.06309762760762,640,-51.22556535133523]);">Uluru - Australia</li>

    <form class="geofs-locationForm geofs-stopMousePropagation geofs-stopKeyupPropagation">
        <div class="mdl-textfield mdl-js-textfield" style="width: 100%; padding-right: 86px;">
            <input class="mdl-textfield__input address-input" type="text" id="address" placeholder="Type destination, ICAO, etc.">
            <label class="mdl-textfield__label" for="address">Type destination...</label>
        </div>
        <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" type="submit" style="margin-left: -65px;">Go</button>
    </form>

</ul>
<script>

    window.geofs = window.geofs || {};
    geofs.aircraftList = {};

    geofs.aircraftList['1'] = {name: 'Piper Cub', dir: '|models|aircraft|premium|cub|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['2'] = {name: 'Cessna 172', dir: '|models|aircraft|premium|cessna_172|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['3'] = {name: 'Alphajet PAF', dir: '|models|aircraft|premium|alphajet_paf|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['4'] = {name: 'Boeing 737-700', dir: '|models|aircraft|premium|737_700|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['5'] = {name: 'Embraer Phenom 100', dir: '|models|aircraft|premium|phenom_100|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['6'] = {name: 'de Havilland DHC6 Twin Otter', dir: '|models|aircraft|premium|dhc6|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['7'] = {name: ' F-16 Fighting Falcon', dir: '|models|aircraft|premium|f16|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['8'] = {name: 'Pitts Special S1', dir: '|models|aircraft|premium|pitts|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['9'] = {name: 'Eurocopter EC135', dir: '|models|aircraft|premium|ec135|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['10'] = {name: 'Airbus A380', dir: '|models|aircraft|premium|a380|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['11'] = {name: 'Alisport Silent 2 Electro', dir: '|models|aircraft|premium|silent2|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['12'] = {name: 'Pilatus PC-7 Mk-I', dir: '|models|aircraft|premium|pilatus|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['13'] = {name: 'de Havilland Canada DHC-2 Beaver', dir: '|models|aircraft|premium|dhc2|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['14'] = {name: 'Colomban MC-15 Cri-cri', dir: '|models|aircraft|premium|cricri|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['15'] = {name: 'Lockheed P-38 Lightning F-5B', dir: '|models|aircraft|premium|p38|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['16'] = {name: 'Douglas DC-3', dir: '|models|aircraft|premium|dc3|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['17'] = {name: 'McDonnell Douglas MD-11', dir: '|models|aircraft|md11|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['18'] = {name: 'Sukhoi Su-35', dir: '|models|aircraft|premium|su35|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['20'] = {name: 'Concorde', dir: '|models|aircraft|premium|concorde|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['21'] = {name: 'Zlin Z-50', dir: '|models|aircraft|zlin|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['22'] = {name: 'Cessna 152', dir: '|models|aircraft|cessna|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['23'] = {name: 'Piper PA-28 161 Warrior II', dir: '|models|aircraft|premium|pa28|', 'multiplayerFiles': 'multiplayer.gltf,multiplayer-low.gltf', 'community': 0};geofs.aircraftList['26'] = {name: 'Antonov An-140', dir: '|models|aircraft|AN140|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['40'] = {name: 'Evektor Sportstar', dir: '|models|aircraft|sportstar|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['41'] = {name: 'szd-48-3 Jantar', dir: '|models|aircraft|jantar|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['50'] = {name: 'Paraglider', dir: '|models|aircraft|paraglider|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['51'] = {name: 'Major Tom (hot air balloon)', dir: '|models|aircraft|premium|majortom|', 'multiplayerFiles': 'multiplayer.glb,multiplayer-low.glb', 'community': 0};geofs.aircraftList['52'] = {name: 'Hughes 269a/TH-55 Osage', dir: '|models|aircraft|hughes|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['53'] = {name: 'Goat Airchair', dir: '|models|aircraft|goat|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['235'] = {name: 'Boeing 787-8', dir: '|backend|aircraft|repository|GXD01E_126645_235|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['236'] = {name: 'Embraer E190', dir: '|backend|aircraft|repository|GXD02RZ_126645_236|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['237'] = {name: 'Boeing 767-300ER', dir: '|backend|aircraft|repository|GXD03FI_126645_237|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['238'] = {name: 'Boeing 757-200', dir: '|backend|aircraft|repository|GXD04N_126645_238|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['239'] = {name: 'Airbus A350-900', dir: '|backend|aircraft|repository|GXD05OQ_166617_239|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['240'] = {name: 'Boeing 777-300ER', dir: '|backend|aircraft|repository|Boeing 777-300ER_933_240|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['242'] = {name: 'Airbus A321neo', dir: '|backend|aircraft|repository|D02_933_242|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['244'] = {name: 'Airbus A330-300', dir: '|backend|aircraft|repository|A02_166635_244|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['247'] = {name: 'Bombardier Dash 8 Q400', dir: '|backend|aircraft|repository|E01_166635_247|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['252'] = {name: 'Boeing 747-8 Freighter', dir: '|backend|aircraft|repository|A03_166635_252|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['1000'] = {name: 'Unkown', dir: '|models|aircraft|generics|787|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1001'] = {name: 'Boeing 73x', dir: '|models|aircraft|generics|73x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1002'] = {name: 'Boeing 74x', dir: '|models|aircraft|generics|74x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1003'] = {name: 'Boeing 75x', dir: '|models|aircraft|generics|75x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1004'] = {name: 'Boeing 76x', dir: '|models|aircraft|generics|76x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1005'] = {name: 'Boeing 77x', dir: '|models|aircraft|generics|77x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1006'] = {name: 'Boeing 78x', dir: '|models|aircraft|generics|78x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1007'] = {name: 'Airbus A31x', dir: '|models|aircraft|generics|a31x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1008'] = {name: 'Airbus A32x', dir: '|models|aircraft|generics|a32x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1009'] = {name: 'Airbus A33x', dir: '|models|aircraft|generics|a33x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1010'] = {name: 'Airbus A34x', dir: '|models|aircraft|generics|a34x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1011'] = {name: 'Airbus A35x', dir: '|models|aircraft|generics|a35x|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1012'] = {name: 'Airbus A380', dir: '|models|aircraft|generics|a380|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1013'] = {name: 'ATR42', dir: '|models|aircraft|generics|atr42|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1014'] = {name: 'BAE146', dir: '|models|aircraft|generics|bae146|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1015'] = {name: 'CRJ 700', dir: '|models|aircraft|generics|crj700|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1016'] = {name: 'CRJ 900', dir: '|models|aircraft|generics|crj900|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1017'] = {name: 'Embraer 170', dir: '|models|aircraft|generics|e170|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1018'] = {name: 'Embraer 190', dir: '|models|aircraft|generics|e190|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1019'] = {name: 'Piper PA-28', dir: '|models|aircraft|generics|pa28|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1020'] = {name: 'Dash 8', dir: '|models|aircraft|generics|dh8|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1021'] = {name: 'Cessna Citation', dir: '|models|aircraft|generics|c25a|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1022'] = {name: 'Cessna', dir: '|models|aircraft|generics|c182|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1023'] = {name: 'MD11', dir: '|models|aircraft|generics|md11|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1024'] = {name: 'Mirage 2000', dir: '|models|aircraft|generics|mirage2000|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1025'] = {name: 'Helicopter', dir: '|models|aircraft|generics|heli|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1026'] = {name: 'Cirrus SR22', dir: '|models|aircraft|generics|sr22|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1027'] = {name: 'Ground Vehicle', dir: '|models|objects|vehicles|truck|', 'multiplayerFiles': '', 'community': 0};geofs.aircraftList['1069'] = {name: 'Cirrus SR22 GTS Turbo', dir: '|backend|aircraft|repository|E02_166635_1069|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2003'] = {name: 'Boeing 737-800', dir: '|backend|aircraft|repository|Boeing 737-800_187219_1003|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2004'] = {name: 'CRJ-900', dir: '|backend|aircraft|repository|CRJ-900_187219_1004|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2153'] = {name: 'Airbus A340-600', dir: '|backend|aircraft|repository|G5_166635_2153|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2310'] = {name: 'A-10C Thunderbolt II', dir: '|backend|aircraft|repository|A10 II Warthog_310810_2310|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2364'] = {name: 'Lockheed SR-71A Blackbird', dir: '|backend|aircraft|repository|B-1_241731_2364|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2386'] = {name: 'Boeing 787-9 Dreamliner', dir: '|backend|aircraft|repository|G8_166635_2386|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2395'] = {name: 'BAe 146-300/Avro RJ100', dir: '|backend|aircraft|repository|_310810_2395|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2418'] = {name: 'ATR 72-600 (HOP!)', dir: '|backend|aircraft|repository|New P-Series_267286_2418|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2420'] = {name: 'ATR 72-600 (Silver)', dir: '|backend|aircraft|repository|ATR 72-600 (SAS)_267286_2420|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2426'] = {name: 'ATR 72-600 (UTair)', dir: '|backend|aircraft|repository|ATR 72-500 (UTair)_267286_2426|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2461'] = {name: 'Cirrus Vision Jet/SF50 G2', dir: '|backend|aircraft|repository|GA-1_310810_2461|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2556'] = {name: 'Northrop Grumman B-2 Spirit', dir: '|backend|aircraft|repository|_260077_2556|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2581'] = {name: 'F-14B Tomcat ', dir: '|backend|aircraft|repository|MA-2_310810_2581|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2700'] = {name: 'Embraer ERJ-195AR (Breeze)', dir: '|backend|aircraft|repository|_228942_2700|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2706'] = {name: 'Bombardier CRJ 200', dir: '|backend|aircraft|repository|Bomabardier CRJ 200_388316_2706|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2726'] = {name: 'Scaled 339 \"SpaceShipTwo\"', dir: '|backend|aircraft|repository|P140_267286_2726|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2750'] = {name: 'Caproni Stipa', dir: '|backend|aircraft|repository|Caproni Stipa_358831_2750|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2752'] = {name: 'Scaled 348 \"WhiteKnightTwo\"', dir: '|backend|aircraft|repository|P141_267286_2752|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2769'] = {name: 'Boeing 737 Max 8 (TUI)', dir: '|backend|aircraft|repository|EL AL 737-900_427352_2769|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2772'] = {name: 'Boeing 737 Max 8 (SpiceJet)', dir: '|backend|aircraft|repository|SpiceJet 737-900_427352_2772|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2788'] = {name: 'Antonov An-225 Mriya', dir: '|backend|aircraft|repository|An-225 2.0_260077_2788|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2806'] = {name: 'Sikorsky S-97 Raider', dir: '|backend|aircraft|repository|M150V_267286_2806|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2808'] = {name: 'Supermarine Spitfire Mk XIV', dir: '|backend|aircraft|repository|HA-1_310810_2808|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2840'] = {name: 'Bell UH-1H Iroquois', dir: '|backend|aircraft|repository|UH-1D_286491_2840|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2843'] = {name: 'A220-300 (Air Tanzania)', dir: '|backend|aircraft|repository|a220-300_230250_2843|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2844'] = {name: 'Falcon 9', dir: '|backend|aircraft|repository|Falcon 9_358831_2844|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2852'] = {name: 'Rozière Balloon', dir: '|backend|aircraft|repository|A140_267286_2852|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2856'] = {name: 'Airbus A400M Atlas', dir: '|backend|aircraft|repository|Airbus A400M Atlas_388316_2856|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2857'] = {name: 'F-22 Raptor', dir: '|backend|aircraft|repository|F22 Test_285706_2857|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2864'] = {name: 'AgustaWestland AW609', dir: '|backend|aircraft|repository|M200V_267286_2864|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2865'] = {name: 'Airbus a320neo(Air India)', dir: '|backend|aircraft|repository|airbus a320-214 (Indigo)_427352_2865|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2870'] = {name: 'Airbus a320neo (Flynas)', dir: '|backend|aircraft|repository|airbus a320-214 (Eurowings)_427352_2870|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2871'] = {name: 'Airbus a320neo (Iberia)', dir: '|backend|aircraft|repository|airbus a320-214 (Easyjet)_427352_2871|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2878'] = {name: 'Airbus A319 (Air China)', dir: '|backend|aircraft|repository|Saudi Airbus A319_230250_2878|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2879'] = {name: 'Airbus A319 (Finnair) ', dir: '|backend|aircraft|repository|Philpians a319_230250_2879|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2892'] = {name: 'SAAB 340', dir: '|backend|aircraft|repository|SAAB 340_427352_2892|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2899'] = {name: 'A220-300 (Swiss)', dir: '|backend|aircraft|repository|Air Baltic  A220_230250_2899|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2943'] = {name: 'Embraer EMB120 Brasillia ', dir: '|backend|aircraft|repository|AW609_230250_2943|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2948'] = {name: '(JAaMDG) North American XB-70 Valkyrie', dir: '|backend|aircraft|repository|(JAaMDG) North American XB-70 Valkyrie_321805_2948|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2951'] = {name: 'Dassault nEUROn ', dir: '|backend|aircraft|repository|Dassault nEUROn UCAV_388316_2951|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2953'] = {name: 'Space Shuttle Atlantis (limited)', dir: '|backend|aircraft|repository|P180_267286_2953|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2973'] = {name: 'Airbus A350-1000 XWB', dir: '|backend|aircraft|repository|_260077_2973|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2976'] = {name: 'Pilatus PC12', dir: '|backend|aircraft|repository|Pilatus PC12_230250_2976|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2988'] = {name: '(TBSG, GeoAD) North American X-15', dir: '|backend|aircraft|repository|(TBSG, GeoAD) North American X-15_321805_2988|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['2989'] = {name: 'MQ9B Reaper', dir: '|backend|aircraft|repository|MQ9B Reaper_388316_2989|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3011'] = {name: 'Boeing 737 Max 8 (Norwegian)', dir: '|backend|aircraft|repository|737max_427352_3011|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3036'] = {name: 'Embraer E195-E2', dir: '|backend|aircraft|repository|Binter E195-E2_230250_3036|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3049'] = {name: 'Lockheed Martin P-791 (LMH-1)', dir: '|backend|aircraft|repository|P200_267286_3049|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3054'] = {name: 'Boeing 737-800 [Spice9]', dir: '|backend|aircraft|repository|Boeing 737Max 8 (TUI)_427352_3054|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3109'] = {name: 'Pilatus PC24', dir: '|backend|aircraft|repository|PC24_230250_3109|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3140'] = {name: 'Airbus A319 (United)', dir: '|backend|aircraft|repository|Lufthansa A319-111_230250_3140|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3179'] = {name: 'Boeing 787-10 Dreamliner (British Airways)', dir: '|backend|aircraft|repository|Boeing 787-10 Dreamliner (British Airways)_427352_3179|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3180'] = {name: 'Boeing 787-10 Dreamliner (Etihad)', dir: '|backend|aircraft|repository|Boeing 787-10 Dreamliner (Etihad)_427352_3180|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3289'] = {name: 'HAL-Dornier 228-100', dir: '|backend|aircraft|repository|HAL-Dornier 228-100_427352_3289|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3292'] = {name: 'Boeing p8I Neptune', dir: '|backend|aircraft|repository|Boeing p8I Neptune_427352_3292|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3307'] = {name: 'Bombardier CRJ-700', dir: '|backend|aircraft|repository|CRJ-700_450602_3307|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3341'] = {name: 'Embraer ERJ-170', dir: '|backend|aircraft|repository|ERJ-170 2_450602_3341|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3460'] = {name: 'Grumman E-2C Hawkeye', dir: '|backend|aircraft|repository|Grumman E-2 Hawkeye_286491_3460|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3534'] = {name: 'airbus a320-214(Easyjet)', dir: '|backend|aircraft|repository|airbus a320-214(Sri Lankan)_427352_3534|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3575'] = {name: ' Boeing 787-9[Spice9]', dir: '|backend|aircraft|repository|Boeing 787-10 Dreamliner (ANA)_427352_3575|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3591'] = {name: 'F-15C Eagle', dir: '|backend|aircraft|repository|F-15C_450602_3591|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['3617'] = {name: 'Dassault Mirage 2000-5', dir: '|backend|aircraft|repository|Dassault Mirage 2000-5_286491_3617|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['4017'] = {name: 'Embraer ERJ145LR (by Spice 9) &', dir: '|backend|aircraft|repository|ERJ145AR_230250_4017|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['4090'] = {name: 'Robinson R-44', dir: '|backend|aircraft|repository|Robinson R44_402407_4090|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['4172'] = {name: 'HAL LCA Tejas mk1 (IOC)', dir: '|backend|aircraft|repository|HAL LCA Tejas mk1 (IOC)_427352_4172|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['4197'] = {name: 'Robinson R22', dir: '|backend|aircraft|repository|Robinson R22_402407_4197|', 'multiplayerFiles': '', 'community': 1};geofs.aircraftList['4251'] = {name: 'Chance Vought F4U-1D Corsair', dir: '|backend|aircraft|repository|M125_267286_4251|', 'multiplayerFiles': '', 'community': 1};
</script>

<ul class="geofs-list geofs-toggle-panel geofs-aircraft-list">

    <li class="geofs-list-collapsible-item geofs-notstudent-role">Community contributed<ul class="geofs-collapsible"><li data-aircraft="3575"> Boeing 787-9[Spice9] (by Spice_9)</li><li data-aircraft="2948">(JAaMDG) North American XB-70 Valkyrie (by Johani_(NeoAD))</li><li data-aircraft="2988">(TBSG, GeoAD) North American X-15 (by Johani_(NeoAD))</li><li data-aircraft="2310">A-10C Thunderbolt II (by Eco[LAC])</li><li data-aircraft="2843">A220-300 (Air Tanzania) (by GT-VRA)</li><li data-aircraft="2899">A220-300 (Swiss) (by GT-VRA)</li><li data-aircraft="2864">AgustaWestland AW609 (by JAaMDG)</li><li data-aircraft="2878">Airbus A319 (Air China) (by GT-VRA)</li><li data-aircraft="2879">Airbus A319 (Finnair)  (by GT-VRA)</li><li data-aircraft="3140">Airbus A319 (United) (by GT-VRA)</li><li data-aircraft="3534">airbus a320-214(Easyjet) (by Spice_9)</li><li data-aircraft="2870">Airbus a320neo (Flynas) (by Spice_9)</li><li data-aircraft="2871">Airbus a320neo (Iberia) (by Spice_9)</li><li data-aircraft="2865">Airbus a320neo(Air India) (by Spice_9)</li><li data-aircraft="242">Airbus A321neo (by LRX)</li><li data-aircraft="244">Airbus A330-300 (by LRX)</li><li data-aircraft="2153">Airbus A340-600 (by LRX)</li><li data-aircraft="2973">Airbus A350-1000 XWB (by Nightshade[ERO][CC_Dev])</li><li data-aircraft="239">Airbus A350-900 (by GX Development)</li><li data-aircraft="2856">Airbus A400M Atlas (by Aero281)</li><li data-aircraft="2788">Antonov An-225 Mriya (by Nightshade[ERO][CC_Dev])</li><li data-aircraft="2418">ATR 72-600 (HOP!) (by JAaMDG)</li><li data-aircraft="2420">ATR 72-600 (Silver) (by JAaMDG)</li><li data-aircraft="2426">ATR 72-600 (UTair) (by JAaMDG)</li><li data-aircraft="2395">BAe 146-300/Avro RJ100 (by Eco[LAC])</li><li data-aircraft="2840">Bell UH-1H Iroquois (by ElonMusk(VrA)(LAC))</li><li data-aircraft="3011">Boeing 737 Max 8 (Norwegian) (by Spice_9)</li><li data-aircraft="2772">Boeing 737 Max 8 (SpiceJet) (by Spice_9)</li><li data-aircraft="2769">Boeing 737 Max 8 (TUI) (by Spice_9)</li><li data-aircraft="2003">Boeing 737-800 (by King  Solomon)</li><li data-aircraft="3054">Boeing 737-800 [Spice9] (by Spice_9)</li><li data-aircraft="252">Boeing 747-8 Freighter (by LRX)</li><li data-aircraft="238">Boeing 757-200 (by GX Development)</li><li data-aircraft="237">Boeing 767-300ER (by GX Development)</li><li data-aircraft="240">Boeing 777-300ER (by LRX)</li><li data-aircraft="3179">Boeing 787-10 Dreamliner (British Airways) (by Spice_9)</li><li data-aircraft="3180">Boeing 787-10 Dreamliner (Etihad) (by Spice_9)</li><li data-aircraft="235">Boeing 787-8 (by GX Development)</li><li data-aircraft="2386">Boeing 787-9 Dreamliner (by LRX)</li><li data-aircraft="3292">Boeing p8I Neptune (by Spice_9)</li><li data-aircraft="2706">Bombardier CRJ 200 (by Aero281)</li><li data-aircraft="3307">Bombardier CRJ-700 (by AriakimTaiyo)</li><li data-aircraft="247">Bombardier Dash 8 Q400 (by LRX)</li><li data-aircraft="2750">Caproni Stipa (by Echo_3)</li><li data-aircraft="4251">Chance Vought F4U-1D Corsair (by JAaMDG)</li><li data-aircraft="1069">Cirrus SR22 GTS Turbo (by LRX)</li><li data-aircraft="2461">Cirrus Vision Jet/SF50 G2 (by Eco[LAC])</li><li data-aircraft="2004">CRJ-900 (by King  Solomon)</li><li data-aircraft="3617">Dassault Mirage 2000-5 (by ElonMusk(VrA)(LAC))</li><li data-aircraft="2951">Dassault nEUROn  (by Aero281)</li><li data-aircraft="236">Embraer E190 (by GX Development)</li><li data-aircraft="3036">Embraer E195-E2 (by GT-VRA)</li><li data-aircraft="2943">Embraer EMB120 Brasillia  (by GT-VRA)</li><li data-aircraft="3341">Embraer ERJ-170 (by AriakimTaiyo)</li><li data-aircraft="2700">Embraer ERJ-195AR (Breeze) (by Featherway)</li><li data-aircraft="4017">Embraer ERJ145LR (by Spice 9) & (by GT-VRA)</li><li data-aircraft="2581">F-14B Tomcat  (by Eco[LAC])</li><li data-aircraft="3591">F-15C Eagle (by AriakimTaiyo)</li><li data-aircraft="2857">F-22 Raptor (by SpaceRage)</li><li data-aircraft="2844">Falcon 9 (by Echo_3)</li><li data-aircraft="3460">Grumman E-2C Hawkeye (by ElonMusk(VrA)(LAC))</li><li data-aircraft="4172">HAL LCA Tejas mk1 (IOC) (by Spice_9)</li><li data-aircraft="3289">HAL-Dornier 228-100 (by Spice_9)</li><li data-aircraft="3049">Lockheed Martin P-791 (LMH-1) (by JAaMDG)</li><li data-aircraft="2364">Lockheed SR-71A Blackbird (by GeoAD)</li><li data-aircraft="2989">MQ9B Reaper (by Aero281)</li><li data-aircraft="2556">Northrop Grumman B-2 Spirit (by Nightshade[ERO][CC_Dev])</li><li data-aircraft="2976">Pilatus PC12 (by GT-VRA)</li><li data-aircraft="3109">Pilatus PC24 (by GT-VRA)</li><li data-aircraft="4090">Robinson R-44 (by (CCDev)DevHunter77)</li><li data-aircraft="4197">Robinson R22 (by (CCDev)DevHunter77)</li><li data-aircraft="2852">Rozière Balloon (by JAaMDG)</li><li data-aircraft="2892">SAAB 340 (by Spice_9)</li><li data-aircraft="2726">Scaled 339 "SpaceShipTwo" (by JAaMDG)</li><li data-aircraft="2752">Scaled 348 "WhiteKnightTwo" (by JAaMDG)</li><li data-aircraft="2806">Sikorsky S-97 Raider (by JAaMDG)</li><li data-aircraft="2953">Space Shuttle Atlantis (limited) (by JAaMDG)</li><li data-aircraft="2808">Supermarine Spitfire Mk XIV (by Eco[LAC])</li></ul></li><li data-aircraft="1"><img data-deferredsrc="images/planes/cub.png"/>Piper Cub<div data-aircraft="1" data-livery="0"><img data-deferredsrc="images/planes/cub_0.png"/>Yellow</div><div data-aircraft="1" data-livery="1"><img data-deferredsrc="images/planes/cub_1.png"/>Red</div></li><li data-aircraft="2"><img data-deferredsrc="images/planes/c172.png"/>Cessna 172<div data-aircraft="2" data-livery="0"><img data-deferredsrc="images/planes/c172_0.png"/>Classic</div><div data-aircraft="2" data-livery="1"><img data-deferredsrc="images/planes/c172_1.png"/>Modern</div></li><li data-aircraft="3"><img data-deferredsrc="images/planes/alphajet.png"/>Alphajet PAF</li><li data-aircraft="4"><img data-deferredsrc="images/planes/737-700.png"/>Boeing 737-700<div data-aircraft="4" data-livery="0"><img data-deferredsrc="images/planes/737-700_0.png"/>KLM</div><div data-aircraft="4" data-livery="1"><img data-deferredsrc="images/planes/737-700_1.png"/>United Airlines</div><div data-aircraft="4" data-livery="2"><img data-deferredsrc="images/planes/737-700_2.png"/>ANA</div><div data-aircraft="4" data-livery="3"><img data-deferredsrc="images/planes/737-700_3.png"/>Southwest</div><div data-aircraft="4" data-livery="4"><img data-deferredsrc="images/planes/737-700_4.png"/>WestJet</div><div data-aircraft="4" data-livery="5"><img data-deferredsrc="images/planes/737-700_5.png"/>GOL</div></li><li data-aircraft="5"><img data-deferredsrc="images/planes/phenom.png"/>Embraer Phenom 100</li><li data-aircraft="6"><img data-deferredsrc="images/planes/dhc6.png"/>de Havilland DHC6 Twin Otter<div data-aircraft="6" data-livery="0"><img data-deferredsrc="images/planes/dhc6_0.png"/>Flybe</div><div data-aircraft="6" data-livery="1"><img data-deferredsrc="images/planes/dhc6_1.png"/>Canadian Air Force</div></li><li data-aircraft="7"><img data-deferredsrc="images/planes/f16.png"/> F-16 Fighting Falcon</li><li data-aircraft="8"><img data-deferredsrc="images/planes/pitts.png"/>Pitts Special S1<div data-aircraft="8" data-livery="0"><img data-deferredsrc="images/planes/pitts_0.png"/>Classic Red</div><div data-aircraft="8" data-livery="1"><img data-deferredsrc="images/planes/pitts_1.png"/>Airshow</div></li><li data-aircraft="9"><img data-deferredsrc="images/planes/ec135.png"/>Eurocopter EC135</li><li data-aircraft="10"><img data-deferredsrc="images/planes/a380.png"/>Airbus A380<div data-aircraft="10" data-livery="0"><img data-deferredsrc="images/planes/a380_0.png"/>Emirates</div><div data-aircraft="10" data-livery="1"><img data-deferredsrc="images/planes/a380_1.png"/>Air France</div><div data-aircraft="10" data-livery="2"><img data-deferredsrc="images/planes/a380_2.png"/>Qantas</div></li><li data-aircraft="11"><img data-deferredsrc="images/planes/silent2.png"/>Alisport Silent 2 Electro</li><li data-aircraft="12"><img data-deferredsrc="images/planes/pilatus.png"/>Pilatus PC-7 Mk-I</li><li data-aircraft="13"><img data-deferredsrc="images/planes/dhc2.png"/>de Havilland Canada DHC-2 Beaver<div data-aircraft="13" data-livery="0"><img data-deferredsrc="images/planes/dhc2_0.png"/>EPOCH Alaska Air</div><div data-aircraft="13" data-livery="1"><img data-deferredsrc="images/planes/dhc2_1.png"/>N963DH Green-White</div><div data-aircraft="13" data-livery="2"><img data-deferredsrc="images/planes/dhc2_2.png"/>N323KT Red-White</div><div data-aircraft="13" data-livery="3"><img data-deferredsrc="images/planes/dhc2_3.png"/>N295B White-Brown</div><div data-aircraft="13" data-livery="4"><img data-deferredsrc="images/planes/dhc2_4.png"/>Lakeland Airways</div><div data-aircraft="13" data-livery="5"><img data-deferredsrc="images/planes/dhc2_5.png"/>Kenmore 66Z</div><div data-aircraft="13" data-livery="6"><img data-deferredsrc="images/planes/dhc2_6.png"/>Clipper Aviation</div><div data-aircraft="13" data-livery="7"><img data-deferredsrc="images/planes/dhc2_7.png"/>Civil Air Patrol</div><div data-aircraft="13" data-livery="8"><img data-deferredsrc="images/planes/dhc2_8.png"/>Alaska Forestry</div></li><li data-aircraft="14"><img data-deferredsrc="images/planes/cricri.png"/>Colomban MC-15 Cri-cri<div data-aircraft="14" data-livery="0"><img data-deferredsrc="images/planes/cricri_0.png"/>Criquet</div><div data-aircraft="14" data-livery="1"><img data-deferredsrc="images/planes/cricri_1.png"/>Bleu Blanc Rouge</div><div data-aircraft="14" data-livery="2"><img data-deferredsrc="images/planes/cricri_2.png"/>Camo</div></li><li data-aircraft="15"><img data-deferredsrc="images/planes/p38.png"/>Lockheed P-38 Lightning F-5B<div data-aircraft="15" data-livery="0"><img data-deferredsrc="images/planes/p38_0.png"/>Navy</div><div data-aircraft="15" data-livery="1"><img data-deferredsrc="images/planes/p38_1.png"/>Saint-Exupery</div></li><li data-aircraft="16"><img data-deferredsrc="images/planes/dc3.png"/>Douglas DC-3</li><li data-aircraft="17"><img data-deferredsrc="images/planes/md11.png"/>McDonnell Douglas MD-11</li><li data-aircraft="18"><img data-deferredsrc="images/planes/su35.png"/>Sukhoi Su-35<div data-aircraft="18" data-livery="0"><img data-deferredsrc="images/planes/su35_0.png"/>Akula 35</div><div data-aircraft="18" data-livery="1"><img data-deferredsrc="images/planes/su35_1.png"/>Russia Bort 01</div><div data-aircraft="18" data-livery="2"><img data-deferredsrc="images/planes/su35_2.png"/>Russia Bort 06</div><div data-aircraft="18" data-livery="3"><img data-deferredsrc="images/planes/su35_3.png"/>Russia Bort 901</div><div data-aircraft="18" data-livery="4"><img data-deferredsrc="images/planes/su35_4.png"/>Ho Ho Ho</div></li><li data-aircraft="20"><img data-deferredsrc="images/planes/concorde.png"/>Concorde<div data-aircraft="20" data-livery="0"><img data-deferredsrc="images/planes/concorde_0.png"/>British Airways</div><div data-aircraft="20" data-livery="1"><img data-deferredsrc="images/planes/concorde_1.png"/>Air France</div><div data-aircraft="20" data-livery="2"><img data-deferredsrc="images/planes/concorde_2.png"/>Pepsi</div></li><li data-aircraft="21"><img data-deferredsrc="images/planes/zlin.png"/>Zlin Z-50</li><li data-aircraft="22"><img data-deferredsrc="images/planes/c152.png"/>Cessna 152</li><li data-aircraft="26"><img data-deferredsrc="images/planes/an140.png"/>Antonov An-140</li><li data-aircraft="40"><img data-deferredsrc="images/planes/sportstar.png"/>Evektor Sportstar</li><li data-aircraft="41"><img data-deferredsrc="images/planes/jantar.png"/>szd-48-3 Jantar</li><li data-aircraft="50"><img data-deferredsrc="images/planes/paraglider.png"/>Paraglider</li><li data-aircraft="51"><img data-deferredsrc="images/planes/tom.png"/>Major Tom (hot air balloon)<div data-aircraft="51" data-livery="0"><img data-deferredsrc="images/planes/tom_0.png"/>Major Tom</div><div data-aircraft="51" data-livery="1"><img data-deferredsrc="images/planes/tom_1.png"/>Pixels</div><div data-aircraft="51" data-livery="2"><img data-deferredsrc="images/planes/tom_2.png"/>GeoFS</div><div data-aircraft="51" data-livery="3"><img data-deferredsrc="images/planes/tom_3.png"/>Losanges</div><div data-aircraft="51" data-livery="4"><img data-deferredsrc="images/planes/tom_4.png"/>Red</div><div data-aircraft="51" data-livery="5"><img data-deferredsrc="images/planes/tom_5.png"/>Orange</div><div data-aircraft="51" data-livery="6"><img data-deferredsrc="images/planes/tom_6.png"/>Scale</div><div data-aircraft="51" data-livery="7"><img data-deferredsrc="images/planes/tom_7.png"/>Christmas</div></li><li data-aircraft="52"><img data-deferredsrc="images/planes/hughes.png"/>Hughes 269a/TH-55 Osage</li><li data-aircraft="53"><img data-deferredsrc="images/planes/goat.png"/>Goat Airchair</li></ul>

<script>
    // de-obfuscate path so Googlebot does not crawl and follow therese as links
    for (var i in geofs.aircraftList) {
        geofs.aircraftList[i].path = geofs.aircraftList[i].dir.replace(/\|/gi, '/');
    }
</script><ul class="geofs-list geofs-toggle-panel geofs-player-list geofs-authenticated" data-onshow="{ui.initPlayerList()}" data-onhide="{ui.clearPlayerList()}"></ul><!-- Navigation panel --><div class="geofs-map-list geofs-toggle-panel" data-onshow="{ui.openMap()}" data-onhide="{ui.closeMap()}" data-noblur="true">
            <div class="geofs-createPath">Create flight path</div>
            <div class="geofs-clearPath">Clear path</div>
            <div class="geofs-map-viewport geofs-stopMousePropagation"></div>

            <!-- Legacy autopilot -->
            <div class="geofs-autopilot geofs-stopKeyboardPropagation">
                <h6>Autopilot</h6>
                <button class="mdl-button mdl-js-button mdl-button--raised geofs-autopilot-toggle" onclick="geofs.autopilot.toggle();" title="Toggle autopilot on/off - [A]">Disengaged</button>
                <div class="geofs-autopilot-displays">
                    <label>
                        Altitude
                        <input type="number" placeholder="00000" min="0" step="1000" class="geofs-autopilot-altitude" onchange="geofs.autopilot.setAltitude(this.value);"><span>Ft.</span>
                    </label>
                    <label>
                        Heading
                        <input type="number" placeholder="000" min="0" max="359" step="1" class="geofs-autopilot-course" onchange="geofs.autopilot.setCourse(this.value);"><span>Deg.</span>
                    </label>
                    <label>
                        Speed
                        <input type="number" placeholder="0" min="0" step="10" class="geofs-autopilot-speed geofs-autopilot-kias" onchange="geofs.autopilot.setSpeed(this.value);"><span>Kts.</span>
                    </label>
                </div>
            </div>

        </div>

        <!-- Debug panel -->
        <div class="geofs-debug geofs-list geofs-toggle-panel" data-onshow="{geofs.debug.turnOn()}" data-onhide="{geofs.debug.turnOff()}" data-noblur="true">
            <div class="geofs-debugFrame">
                <label>Part name<input type="text" class="debugPartName"></label>
                <label>Collision point index<input title="collision point index" style="width: 20px;" class="debugCollisionPointIndex"></label>
                <p class="debugPartData"></p>
                <label class="checkbox">Beak on Part Name<input type="checkbox" class="debugBreakOnPartName" title="Break on part name"></label>
                <label class="checkbox">Force Source Point<input type="checkbox" class="debugShowForceSource" title="force source point"></label>
                <label class="checkbox">Force Direction<input type="checkbox" class="debugShowForceDirection" title="Force direction"></label>
                <label class="checkbox">Local Position<input type="checkbox" class="debugShowLocalPosition" title="Local position"></label>
                <label class="checkbox">suspension Origin<input type="checkbox" class="debugShowsuspensionOrigin" title="Local position"></label>
                <button class="btn btn-warning" onclick="geofs.killCache = '?killcache=' + Date.now(); geofs.debugResetAircraft = true;">Clear cache</button>
                <button class="btn" onclick="geofs.aircraft.instance.change(geofs.aircraft.instance.id, null, /* forceReload */ true, /*forceReset*/ false);">Just Reload</button>
                <button class="btn" onclick="geofs.aircraft.instance.change(geofs.aircraft.instance.id, null, /* justReload */ true, /*forceReset*/ true);">Full Reload</button>
                <br><label>Object id<input type="text" class="objectId"></label>
                <div class="geofs-debugObjectLlaHtr"></div>
                ---------------- logs ------------------
                <div class="geofs-debugWatch"></div>
                <div class="geofs-debugLog"></div>
            </div>
        </div>
    </div>

    <div class="geofs-ui-right">

        <div class="geofs-startModal">
            <h1>Welcome to GeoFS!</h1>
            <h5>A quick briefing before take-off:</h5>
            <ul style="margin-left: -25px;"><li>+ and - keys to set throttle</li>
                <li>You are flying with the mouse (configurable)</li>
                <li>As you gain speed, gently pull on the stick (mouse down) to take off</li>
                <li>Press R to reset your flight</li>
            </ul><a class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-button--accent geofs-fly-button"><i class="material-icons"></i> Fly!</a>
        </div>

        <div class="geofs-flightSharing-status"></div>

        <div class="geofs-user-dialog">
            <h4 style="white-space: nowrap; flex-grow: 1;"><span class="material-icons" style="font-size: 30px;vertical-align: sub;margin-right: 5px;">perm_identity</span>Pilot <b class="geofs-user-callsign"></b></h4>
            <button class="geofs-ignore-user mdl-button mdl-button--raised mdl-button--colored" title="Block user"><span class="material-icons">pan_tool</span> Block user</button>
            <button class="geofs-share-user geofs-school mdl-button mdl-button--raised mdl-button--accent" title="Share flight and controls with user"><span class="material-icons">group</span> Share flight</button>
            <button class="geofs-join-user mdl-button mdl-button--raised"><span class="material-icons" title="Join user in flight">call_merge</span> Join user in flight</button>
            <button class="geofs-cancel mdl-button close" title="Close">Close</button>
        </div>

        <!-- Top UI overlay -->
        <div class="geofs-ui-top">

            <div class="geofs-autopilot-bar">
                <div class="control-pad geofs-autopilot-pad" title="Toggle autopilot on/off">
                    <div class="control-pad-label transp-pad">AUTOPILOT</div>
                </div>
                <div class="geofs-autopilot-controls">
                    <div class="geofs-autopilot-control">
                        <a class="numberDown">-</a><input class="numberValue geofs-autopilot-speed" min="0" step="10" data-method="setSpeed" maxlength="3" value="0"><a class="numberUp">+</a>
                        <span>IAS</span>
                    </div>
                    <div class="geofs-autopilot-control">
                        <a class="numberDown">-</a><input class="numberValue geofs-autopilot-course" min="0" max="359" data-loop="true" step="1" data-method="setCourse" maxlength="3" value="000"><a class="numberUp">+</a>
                        <span class="geofs-autopilot-switch geofs-autopilot-mode">
                            <a class="switchLeft geofs-autopilot-HDG green-pad" data-method="setMode" value="HDG">HDG</a><a class="switchRight geofs-autopilot-NAV" data-method="setMode" value="NAV">NAV</a>
                        </span>
                    </div>
                    <div class="geofs-autopilot-control">
                        <a class="numberDown">-</a><input class="numberValue geofs-autopilot-altitude" min="0" max="100000" step="500" data-method="setAltitude" maxlength="5" value="00000"><a class="numberUp">+</a>
                        <span>ALTITUDE</span>
                    </div>
                    <div class="geofs-autopilot-control">
                        <a class="numberDown">-</a><input class="numberValue geofs-autopilot-verticalSpeed" min="-6000" max="6000" step="100" data-method="setVerticalSpeed" maxlength="5" value="00000"><a class="numberUp">+</a>
                        <span>VERT SPEED</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Radio box -->
        <div class="geofs-radio-bar">
            <div class="geofs-radio-controls">
                <div class="geofs-radio-control geofs-adf-frequency">
                    <span class="geofs-radio-label">ADF</span><input class="geofs-radio-display" name="ADFFrequency"><button class="geofs-radio-ident" data-unit="ADF">ident</button>
                </div>
                <div class="geofs-radio-control geofs-nav-frequency">
                    <span class="geofs-radio-label">NAV</span><input class="geofs-radio-display" name="NAVFrequency"><button class="geofs-radio-ident" data-unit="NAV1">ident</button>
                </div>
                <div class="geofs-radio-control geofs-radio-OBS">
                    <span class="geofs-radio-label">OBS</span><input class="geofs-radio-display" name="radioOBS"></div>
                <div class="geofs-radio-control">
                    <span class="geofs-radio-label">DME</span><input class="geofs-radio-display" name="dme"><span class="geofs-radio-unit">NM</span>
                    <input class="geofs-radio-display" name="groundSpeed"><span class="geofs-radio-unit">KTS</span>
                    <input class="geofs-radio-display" name="timeToStation"><span class="geofs-radio-unit">MIN</span>
                </div>
            </div>
            <div class="control-pad geofs-radio-pad" title="Open radio navigation controls">
                <div class="control-pad-label transp-pad">RADIO</div>
            </div>
        </div>

        <!-- Canvas placeholder -->
        <div id="geofs-ui-3dview" class="geofs-ui-3dview">

            <div class="geofs-crashOverlay">
                You crashed<br><span>click to reset</span>
            </div>

            <!-- Instrument container -->
            <div class="geofs-instruments-container"></div>
            <div class="geofs-indicators-container"></div>
            <div class="geofs-overlay-container"></div>

            <!-- overlayed div to fix Cesium mouse event bug in IE -->
            <div class="geofs-canvas-mouse-overlay">

                <div class="geofs-creditContainer"></div>

                <a href="/" class="geofs-home-button" title="GeoFS home page"><i class="material-icons"></i></a>

                <div class="geofs-touch-controls">

                    <div class="geofs-view-pad"></div>

                    <!-- Touch control pads -->
                    <div class="geofs-throttle-pad">
                        <div class="geofs-throttle-cursor"></div>
                    </div>
                    <div class="geofs-rudder-pad">
                        <div class="geofs-rudder-cursor"></div>
                    </div>
                    <div class="geofs-control-pad">
                        <div class="geofs-control-trimup"></div>
                        <div class="geofs-control-trimdown"></div>
                        <div class="geofs-control-cursor"></div>
                    </div>
                </div>

                <script>geofs.userRecord={"id":"602445","email":"nvzurzolo@gmail.com","googleid":"111310387754326896562","facebookid":null,"deviceid":null,"schoolid":null,"externalid":null,"firstname":"TotallyRealElonMusk","lastname":"","callsign":"ElonMusk[Alt]","sessionId":"rg15tqeea0nccuaunqvvdghm9r","created":"2022-06-12 16:44:19","active":"1","ip":"91.170.6.146","role":"1","muted":"4","banned":"0","lastlogin":"2022-12-03 19:26:22","mailing":"0","password":"***","flighttime":"1381","preferences":null,"mutelist":null,"premium":null,"transactionDate":null,"transactionReference":null,"transactionStatus":null,"transactionMessage":null,"subscribed":null,"subscriptionStart":null,"subscriptionEnd":null,"trial":"0"};</script>
<script>geofs.userRecord.muteList=[];</script>
<script>geofs.userRecord={"id":"602445","email":"nvzurzolo@gmail.com","googleid":"111310387754326896562","facebookid":null,"deviceid":null,"schoolid":null,"externalid":null,"firstname":"TotallyRealElonMusk","lastname":"","callsign":"ElonMusk[Alt]","sessionId":"rg15tqeea0nccuaunqvvdghm9r","created":"2022-06-12 16:44:19","active":"1","ip":"91.170.6.146","role":"1","muted":"4","banned":"0","lastlogin":"2022-12-03 19:26:22","mailing":"0","password":"***","flighttime":"1381","preferences":null,"mutelist":null,"premium":null,"transactionDate":null,"transactionReference":null,"transactionStatus":null,"transactionMessage":null,"subscribed":false,"subscriptionStart":null,"subscriptionEnd":null,"trial":"0","subscriptionDaysLeft":0};</script>
<script>geofs.userRecord.muteList=[];</script>
<script>document.body.classList.remove('geofs-subscribed')</script>
<script>window.executeOnEventDone('afterDeferredload', function() {Cesium.Ion.defaultAccessToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJiMWQ1NWRlMy1lZmM3LTRlNDYtYWQyOS1hZDlmZmMyZGRiZWUiLCJpZCI6NzYsInNjb3BlcyI6WyJhc3IiXSwiYXNzZXRzIjpbMV0sImlhdCI6MTU1MzUwOTAwMX0.AlJJNDP3yr3dOLmcMnuJdsODGrVoSpm9lvtcXuGM99M';});</script>
<script>geofsNewHDState = false;</script>
<script>geofs.geoIpUpdate = function() {jQuery('.geofs-creditContainer').html('<a rel="nofollow" target="_blank" href="https://s2maps.eu">Sentinel-2 cloudless - https://s2maps.eu</a> by <a rel="nofollow" target="_blank" href="https://eox.at/">EOX IT Services GmbH</a> (Contains modified Copernicus Sentinel data 2016 & 2017)');document.body.classList.remove('geofs-hd'); geofs.api.imageryProvider = new Cesium.UrlTemplateImageryProvider({url: 'https://data2.geo-fs.com/sent//{z}/{x}/{reverseY}.jpg',tilingScheme: new Cesium.GeographicTilingScheme({numberOfLevelZeroTilesX:2, numberOfLevelZeroTilesY:1}),hasAlphaChannel: false,enablePickFeatures: false,maximumLevel: 13}); geofs.api.setImageryProvider(geofs.api.imageryProvider, true, 1, 1, 1); geofs.api.viewer.terrainProvider = geofs.api.flatRunwayTerrainProviderInstance = new geofs.api.FlatRunwayTerrainProvider({baseProvider: new Cesium.CesiumTerrainProvider({url: 'https://data2.geo-fs.com/srtm/',requestWaterMask: false, requestVertexNormals:true}),bypass: false,maximumLevel: 12});geofs.api.analytics.event('geofs', 'mode', 'sd', 1);};</script>
<script>window.executeOnEventDone('geofsStarted', function() {if(geofs.api.hdOn === geofsNewHDState) return; jQuery('body').trigger('terrainProviderWillUpdate'); geofs.geoIpUpdate(); geofs.api.hdOn = geofsNewHDState; geofs.api.renderingQuality(); jQuery('body').trigger('terrainProviderUpdate');});</script>
<script>window.executeOnEventDone('afterDeferredload', function() {geofs.mapXYZ = 'https://data2.geo-fs.com/osm/{z}/{x}/{y}.png';});</script>
<script>window.executeOnEventDone('afterDeferredload', function() {jQuery(document).trigger('loginChange');});</script>
<div class="geofs-auth geofs-htmlView">

            <a href="/pages/account.php?action=edit" class="mdl-button mdl-js-button geofs-callsign" title="Your account page">ElonMusk[Alt] <i class="material-icons">account_circle</i></a>
        <a class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect geofs-signout">Sign out</a>

        <a href="/pages/instructions.php" target="_blank" class="geofs-help">
        <i class="material-icons">help_outline</i>
    </a>
</div><div class="geofs-player-count" data-toggle-panel=".geofs-player-list"></div>

                <img data-deferredsrc="/images/hd-logo.png" class="geofs-hd-logo"><!-- Chat section --><div class="geofs-chat-messages geofs-authenticated"></div>
            </div>

        </div>
    </div>

    
        <div class="geofs-adbanner geofs-adsense-container">

            <div class="geofs-refreshTarget">

                <div class="geofs-adsBlockedMessage" style="text-align: center;">
    
<a href="/pages/mobile.php" target="_top" style="display: inline-block; text-align: center; height: 100%; width: 100%; height: 100%;">
<img data-deferredsrc="/images/ba/apps_skyscraper.jpg" style="max-width: 160px; max-height: 100%;" /></a></div><style>
                    .geofs-adbanner ins {
                        width: 302px;
                        max-width: 302px;
                        min-width: 162px;
                    }

                    @media screen and (max-width: 1600px) {
                        .geofs-adbanner ins {
                            width: 162px;
                        }
                    }
                </style><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script><ins class="adsbygoogle" style="display:block;" data-ad-client="ca-pub-1808592532341984" data-ad-slot="5302287636" data-ad-format="vertical"></ins>
            </div>
        </div>

        <script>

            (adsbygoogle = window.adsbygoogle || []).push({});

            window.executeOnEventDone('afterDeferredload', function() {

                geofs.lastFlyTo = new Date().getTime();
		        geofs.adCount = 1;
                $(document).on('flyto', function() {
                    var t = new Date().getTime();
                    if (t - geofs.lastFlyTo > 40000) {

                        if (geofs.adCount % 3 == 0 || window.adsBlocked) { // every three impressions
                            if (window.innerWidth <= 800) {
                                $('.geofs-refreshTarget').htmlView('load', '/pages/common/includes/ba/apps.php?type=2');
                            }
                            else {
                                $('.geofs-refreshTarget').htmlView('load', '/pages/common/includes/ba/loader.php?type=2');
                            }
                        }
                        else {
                            $('.geofs-refreshTarget').empty().html('<scr'+'ipt async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"><'+'/scr'+'ipt><ins class="adsbygoogle" style="display:block;'+(geofs.api.isMobile()?'height:100px;':'')+'" data-ad-client="ca-pub-1808592532341984" data-ad-slot="5302287636" data-ad-format="vertical"><'+'/ins><scr'+'ipt>(adsbygoogle = window.adsbygoogle || []).push({});<'+'/scr'+'ipt>');
                        }
                        geofs.adCount++;
                        geofs.lastFlyTo = t;
                    }
                });
            });
        </script><!-- Bottom bar --><div class="geofs-ui-bottom">

        <!-- Small screen menu -->
        <button id="small_screen_menu" class="mdl-button mdl-js-button mdl-button--icon geofs-smallScreenOnly">
            <i class="material-icons">more_vert</i>
        </button>

        <!-- Small Screen Menu -->
        <ul class="mdl-menu mdl-menu--top-left mdl-js-menu mdl-js-ripple-effect geofs-smallScreenOnly" for="small_screen_menu"><li class="mdl-menu__item">
                <!-- Pause, mute, reset -->
                <div class="geofs-ui-bottom-box geofs-f-standard-ui">
                    <button class="geofs-button-pause mdl-button mdl-js-button mdl-button--icon" onclick="geofs.togglePause();" title="Pause/Unpause [P]"><i class="material-icons">pause_circle_outline</i></button>
                    <button class="geofs-button-mute mdl-button mdl-js-button mdl-button--icon" onclick="audio.toggleMute();" title="Mute/Unmute sound [S]"><i class="material-icons">volume_off</i></button>
                    <button class="mdl-button mdl-js-button mdl-button--icon" onclick="geofs.resetFlight();" title="Reset the flight [R]"><i class="material-icons">autorenew</i></button>
                    <button class="mdl-button mdl-js-button mdl-button--icon" data-tooltip-classname="mdl-tooltip--top" onclick="flight.recorder.enterPlayback();" title="Watch recorded flight"><i class="material-icons">play_circle_outline</i></button>
                </div>
            </li>
            <li class="mdl-menu__item">
                <button class="mdl-button mdl-js-button geofs-f-standard-ui" data-toggle-panel=".geofs-preference-list" title="Open the settings/options panel [O]"><i class="material-icons">settings</i> Options</button>
            </li>
            <li class="mdl-menu__item">
                <button class="mdl-button mdl-js-button geofs-f-standard-ui" data-toggle-panel=".geofs-map-list" title="Navigation charts [N]"><i class="material-icons">explore</i> Nav</button>
            </li>
            <li class="mdl-menu__item">
                <button class="geofs-button-fullscreen mdl-button mdl-js-button geofs-f-standard-ui" onclick="ui.toggleFullscreen();" style="float: right;" data-tooltip-classname="mdl-tooltip--top" title="Toggle fullscreen">
                    <span class="material-icons geofs-fullscreenIconOpen">open_in_full</span>
                    <span class="material-icons geofs-fullscreenIconClose">close_fullscreen</span>
                    Fullscreen
                </button>
            </li>
        </ul><!-- Full size menu --><!-- Main panels toggle buttons --><button class="mdl-button mdl-js-button geofs-f-standard-ui" data-toggle-panel=".geofs-aircraft-list">Aircraft</button>
        <button class="mdl-button mdl-js-button mdl-button--colored geofs-authenticated geofs-editor-role geofs-f-standard-ui geofs-bigScreenOnly" data-toggle-panel=".geofs-debug">Debug</button>
        <button class="mdl-button mdl-js-button geofs-f-standard-ui" data-toggle-panel=".geofs-location-list">Location</button>

        <!--
            *
            *
            * Camera selector
            *
            *
        -->
        <button id="geofs-camera-selector" class="mdl-button mdl-js-button">Camera</button>

        <ul class="mdl-menu mdl-menu--top-left mdl-js-menu mdl-js-ripple-effect" for="geofs-camera-selector"><li class="geofs-extra-views mdl-menu__item mdl-menu__item--full-bleed-divider">Extra views
                <ul class="mdl-menu geofs-extra-views-holder"><!-- to be filled from aircraft definition --></ul></li>
            <li class="mdl-menu__item" data-camera="0">Follow cam</li>
            <li class="mdl-menu__item" data-camera="1">Cockpit cam</li>
            <li class="mdl-menu__item" data-camera="2">Cockpit-less cam</li>
            <li class="mdl-menu__item" data-camera="3">Chase cam</li>
            <li class="mdl-menu__item" data-camera="4">Free cam</li>
            <li class="mdl-menu__item mdl-menu__item--full-bleed-divider" data-camera="5">Fixed cam</li>
            <li class="mdl-menu__item" data-camera="-1">Reset</li>
        </ul><!-- Options and map --><button class="mdl-button mdl-js-button geofs-f-standard-ui" data-toggle-panel=".geofs-preference-list" title="Open the settings/options panel [O]" data-tooltip-classname="mdl-tooltip--top">Options <i class="material-icons geofs-ui-bottom-icon">settings</i></button>
        <button class="mdl-button mdl-js-button geofs-f-standard-ui geofs-mediumScreenOnly" data-toggle-panel=".geofs-map-list" title="Open the navigation panel [N]" data-tooltip-classname="mdl-tooltip--top">Nav <i class="material-icons geofs-ui-bottom-icon">explore</i></button>
<!--
        <button class="geofs-button-vr mdl-button mdl-js-button geofs-f-standard-ui geofs-editor-role" onclick="ui.vr.toggle();" data-tooltip-classname="mdl-tooltip--top" title="Toggle VR"><img src="/images/vr-icon.png"/></button>
-->
        <style>
            body:not(.fullscreen) .geofs-fullscreenIconClose {display: none;}
            body.fullscreen .geofs-fullscreenIconOpen {display: none;}
        </style><button class="geofs-button-fullscreen mdl-button mdl-js-button geofs-f-standard-ui" onclick="ui.toggleFullscreen();" style="float: right;" data-tooltip-classname="mdl-tooltip--top" title="Toggle fullscreen">
            <span class="material-icons geofs-fullscreenIconOpen">open_in_full</span>
            <span class="material-icons geofs-fullscreenIconClose">close_fullscreen</span>
        </button>

        <a class="mdl-button mdl-js-button geofs-authenticated geofs-editor-role" download="geofs.jpg" href="" onclick="geofs.api.takeCanvasScreenShot(this);" data-tooltip-classname="mdl-tooltip--top" title="Canvas Screenshot" style="float: right;">
            <span class="material-icons">photo_camera</span>
        </a>

        <!-- Pause, mute, reset, playback -->
        <div class="geofs-ui-bottom-box geofs-f-standard-ui geofs-mediumScreenOnly">
            <button class="geofs-button-pause mdl-button mdl-js-button mdl-button--icon" data-tooltip-classname="mdl-tooltip--top" onclick="geofs.togglePause();" title="Pause/Unpause [P]"><i class="material-icons">pause_circle_outline</i></button>
            <button class="geofs-button-mute mdl-button mdl-js-button mdl-button--icon" data-tooltip-classname="mdl-tooltip--top" onclick="audio.toggleMute();" title="Mute/Unmute sound [S]"><i class="material-icons">volume_off</i></button>
            <button class="mdl-button mdl-js-button mdl-button--icon" data-tooltip-classname="mdl-tooltip--top" onclick="geofs.resetFlight();" title="Reset the flight [R]"><i class="material-icons">autorenew</i></button>
            <button class="mdl-button mdl-js-button mdl-button--icon" data-tooltip-classname="mdl-tooltip--top" onclick="flight.recorder.enterPlayback();" title="Watch recorded flight"><i class="material-icons">play_circle_outline</i></button>
        </div>

        <button class="mdl-button mdl-js-button geofs-authenticated mdl-button--icon geofs-f-standard-ui" data-tooltip-classname="mdl-tooltip--top" data-toggle-panel=".geofs-player-list" title="List of online pilots"><i class="material-icons">group</i></button>

        <!-- Chat -->
        <div class="geofs-chat-input-section geofs-authenticated geofs-f-standard-ui geofs-bigScreenOnly">
            <button class="geofs-chat-button mdl-button mdl-js-button" data-tooltip-classname="mdl-tooltip--top" title="Type a chat message [T]">Talk <i class="icon-align-left"></i></button>
            <form class="geofs-chat-form">
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input geofs-chat-input geofs-stopKeyboardPropagation geofs-stopKeyupPropagation geofs-stopMousePropagation" size="30" maxlength="140" type="text" id="chatInput"><label class="mdl-textfield__label" for="chatInput">Message...</label>
                </div>
                <button class="geofs-chat-send-button mdl-button mdl-js-button mdl-button--colored" type="submit">Send</button>
            </form>
        </div>

        <button class="mdl-button mdl-js-button mdl-button--icon geofs-f-standard-ui geofs-orientationReset" data-tooltip-classname="mdl-tooltip--top" title="Reset orientation controls to neutral">
            <i class="material-icons">adjust</i>
        </button>

        <!--
            *
            *
            * Record player
            *
            *
        -->
        <div class="geofs-f-recordPlayer">

            <button class="mdl-button mdl-js-button" onclick="flight.recorder.exitPlayback();" data-tooltip-classname="mdl-tooltip--top" title="Exit record player">Exit player</button>

            <!-- Player controls -->
            <div class="geofs-ui-bottom-box">
                <button class="mdl-button mdl-js-button mdl-button--icon" onclick="flight.recorder.setStep(0, 'set');" data-tooltip-classname="mdl-tooltip--top" title="Begining"><i class="material-icons">fast_rewind</i></button>
                <button class="mdl-button mdl-js-button mdl-button--icon" onclick="flight.recorder.startPlayback();" data-tooltip-classname="mdl-tooltip--top" title="Start playback"><i class="material-icons">play_arrow</i></button>
                <button class="geofs-button-pause mdl-button mdl-js-button mdl-button--icon" onclick="geofs.togglePause();" data-tooltip-classname="mdl-tooltip--top" title="Pause/Unpause playback [P]"><i class="material-icons">pause</i></button>
                <button class="mdl-button mdl-js-button mdl-button--icon" onclick="flight.recorder.setStep(100000, 'set');" data-tooltip-classname="mdl-tooltip--top" title="End"><i class="material-icons">fast_forward</i></button>
            </div>

        </div>

        <!-- player slider -->
        <div class="geofs-f-recordPlayer geofs-slider-container">
            <div class="slider geofs-recordPlayer-slider" data-type="slider" value="0" data-min="0" data-precision="0" style="height: 10px;">
                <div class="slider-rail">
                    <div class="slider-selection">
                        <div class="slider-grippy"><input class="slider-input"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body></html>
